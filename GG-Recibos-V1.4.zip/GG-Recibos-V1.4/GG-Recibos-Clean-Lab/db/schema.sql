-- Create tables for the application

-- Properties table
CREATE TABLE IF NOT EXISTS properties (
  id UUID PRIMARY KEY,
  propiedad VARCHAR(255) NOT NULL,
  tipo VARCHAR(255) NOT NULL,
  direccion TEXT NOT NULL,
  localidad VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Persons table
CREATE TABLE IF NOT EXISTS persons (
  id UUID PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  cuit VARCHAR(255) NOT NULL,
  tipo VARCHAR(50) NOT NULL CHECK (tipo IN ('locador', 'locatario')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Receipts table
CREATE TABLE IF NOT EXISTS receipts (
  id UUID PRIMARY KEY,
  fecha DATE NOT NULL,
  propiedad VARCHAR(255) NOT NULL,
  periodo VARCHAR(255) NOT NULL,
  locador VARCHAR(255) NOT NULL,
  locadorCuit VARCHAR(255) NOT NULL,
  locatario VARCHAR(255) NOT NULL,
  locatarioCuit VARCHAR(255) NOT NULL,
  tipo VARCHAR(255) NOT NULL,
  direccion TEXT NOT NULL,
  localidad VARCHAR(255) NOT NULL,
  alquiler VARCHAR(255) NOT NULL,
  aysa VARCHAR(255),
  edesur VARCHAR(255),
  municipal VARCHAR(255),
  iibb VARCHAR(255),
  otrosGastos VARCHAR(255),
  observaciones TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Header config table
CREATE TABLE IF NOT EXISTS header_config (
  id VARCHAR(50) PRIMARY KEY,
  businessName VARCHAR(255) NOT NULL,
  ownerName VARCHAR(255) NOT NULL,
  licenseInfo VARCHAR(255) NOT NULL,
  location VARCHAR(255) NOT NULL,
  phone VARCHAR(255) NOT NULL,
  taxId VARCHAR(255) NOT NULL,
  taxIdBrutos VARCHAR(255) NOT NULL,
  startDate VARCHAR(255) NOT NULL,
  taxStatus VARCHAR(255) NOT NULL,
  logo TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
