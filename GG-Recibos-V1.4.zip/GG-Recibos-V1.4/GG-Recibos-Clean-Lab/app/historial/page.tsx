import ReceiptHistory from "@/components/receipt-history"

export default function HistoryPage() {
  return (
    <div className="container mx-auto py-10">
      <ReceiptHistory />
    </div>
  )
}
