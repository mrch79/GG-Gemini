import PropertyPrintView from "../../components/property-print-view"

export default function PrintPropertiesPage() {
  return (
    <div className="container py-10">
      <PropertyPrintView />
    </div>
  )
}
